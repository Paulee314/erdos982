NAME        
ROWS
 N  Obj     
 L  r0      
 L  r1      
 L  r2      
 L  r3      
 L  r4      
 L  r5      
 L  r6      
 L  r7      
 L  r8      
 L  r9      
 L  r10     
 L  r11     
 L  r12     
 L  r13     
 L  r14     
 L  r15     
 L  r16     
 L  r17     
 L  r18     
 L  r19     
 L  r20     
 L  r21     
 L  r22     
 L  r23     
 L  r24     
 L  r25     
 L  r26     
 L  r27     
 L  r28     
 L  r29     
 L  r30     
 L  r31     
 L  r32     
 L  r33     
 L  r34     
 L  r35     
 L  r36     
 L  r37     
 L  r38     
 L  r39     
 L  r40     
 L  r41     
 L  r42     
 L  r43     
 L  r44     
 L  r45     
 L  r46     
 L  r47     
 L  r48     
 L  r49     
 L  r50     
 L  r51     
 L  r52     
 L  r53     
 L  r54     
 L  r55     
 L  r56     
 L  r57     
 L  r58     
 L  r59     
 L  r60     
 L  r61     
 L  r62     
 L  r63     
 L  r64     
 L  r65     
 L  r66     
 L  r67     
 L  r68     
 L  r69     
 L  r70     
 L  r71     
 L  r72     
 L  r73     
 L  r74     
 L  r75     
 L  r76     
 L  r77     
 L  r78     
 L  r79     
 L  r80     
 L  r81     
 L  r82     
 L  r83     
 L  r84     
 L  r85     
 L  r86     
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    c0        Obj       -1
    c0        r0        1
    c0        r9        1
    c0        r12       1
    c0        r49       1
    c0        r50       1
    c0        r56       1
    c0        r59       1
    c0        r63       1
    c0        r65       1
    c0        r66       1
    c0        r69       1
    c0        r70       1
    c0        r71       1
    c0        r72       1
    c0        r76       1
    c0        r79       1
    c0        r83       1
    c0        r84       1
    c0        r85       1
    c0        r86       1
    c1        Obj       -1
    c1        r0        1
    c1        r9        1
    c1        r10       1
    c1        r12       1
    c1        r13       1
    c1        r31       1
    c1        r43       1
    c1        r44       1
    c1        r49       1
    c1        r50       1
    c1        r60       1
    c1        r77       1
    c1        r80       1
    c1        r86       1
    c2        Obj       -1
    c2        r1        1
    c2        r9        1
    c2        r10       1
    c2        r11       1
    c2        r16       1
    c2        r50       1
    c2        r64       1
    c2        r67       1
    c2        r74       1
    c2        r78       1
    c2        r81       1
    c2        r82       1
    c2        r86       1
    c3        Obj       -1
    c3        r1        1
    c3        r10       1
    c3        r11       1
    c3        r16       1
    c3        r17       1
    c3        r32       1
    c3        r45       1
    c3        r50       1
    c3        r57       1
    c3        r58       1
    c3        r62       1
    c3        r65       1
    c3        r73       1
    c3        r75       1
    c3        r79       1
    c3        r86       1
    c4        Obj       -1
    c4        r1        1
    c4        r11       1
    c4        r16       1
    c4        r17       1
    c4        r18       1
    c4        r32       1
    c4        r33       1
    c4        r34       1
    c4        r46       1
    c4        r47       1
    c4        r50       1
    c4        r86       1
    c5        Obj       -1
    c5        r2        1
    c5        r12       1
    c5        r13       1
    c5        r14       1
    c5        r15       1
    c5        r16       1
    c5        r17       1
    c5        r18       1
    c5        r19       1
    c5        r86       1
    c6        Obj       -1
    c6        r2        1
    c6        r13       1
    c6        r14       1
    c6        r15       1
    c6        r17       1
    c6        r18       1
    c6        r19       1
    c6        r36       1
    c6        r63       1
    c6        r64       1
    c6        r66       1
    c6        r67       1
    c6        r69       1
    c6        r70       1
    c6        r71       1
    c6        r72       1
    c6        r78       1
    c6        r81       1
    c6        r84       1
    c6        r85       1
    c6        r86       1
    c7        Obj       -1
    c7        r2        1
    c7        r14       1
    c7        r15       1
    c7        r18       1
    c7        r19       1
    c7        r36       1
    c7        r37       1
    c7        r39       1
    c7        r56       1
    c7        r57       1
    c7        r58       1
    c7        r59       1
    c7        r60       1
    c7        r62       1
    c7        r68       1
    c7        r73       1
    c7        r74       1
    c7        r76       1
    c7        r77       1
    c7        r80       1
    c7        r82       1
    c7        r83       1
    c7        r86       1
    c8        Obj       -1
    c8        r2        1
    c8        r15       1
    c8        r19       1
    c8        r36       1
    c8        r37       1
    c8        r38       1
    c8        r39       1
    c8        r40       1
    c8        r86       1
    c9        Obj       -1
    c9        r3        1
    c9        r20       1
    c9        r22       1
    c9        r31       1
    c9        r49       1
    c9        r50       1
    c9        r51       1
    c9        r52       1
    c9        r53       1
    c9        r56       1
    c9        r61       1
    c9        r65       1
    c9        r66       1
    c9        r69       1
    c9        r71       1
    c9        r73       1
    c9        r78       1
    c9        r86       1
    c10       Obj       -1
    c10       r4        1
    c10       r20       1
    c10       r21       1
    c10       r25       1
    c10       r32       1
    c10       r33       1
    c10       r43       1
    c10       r50       1
    c10       r52       1
    c10       r53       1
    c10       r67       1
    c10       r68       1
    c10       r72       1
    c10       r76       1
    c10       r85       1
    c10       r86       1
    c11       Obj       -1
    c11       r4        1
    c11       r21       1
    c11       r25       1
    c11       r26       1
    c11       r33       1
    c11       r35       1
    c11       r48       1
    c11       r50       1
    c11       r52       1
    c11       r53       1
    c11       r57       1
    c11       r58       1
    c11       r59       1
    c11       r70       1
    c11       r80       1
    c11       r81       1
    c11       r82       1
    c11       r83       1
    c11       r84       1
    c11       r86       1
    c12       Obj       -1
    c12       r5        1
    c12       r22       1
    c12       r23       1
    c12       r24       1
    c12       r25       1
    c12       r26       1
    c12       r27       1
    c12       r36       1
    c12       r37       1
    c12       r38       1
    c12       r44       1
    c12       r45       1
    c12       r53       1
    c12       r86       1
    c13       Obj       -1
    c13       r5        1
    c13       r23       1
    c13       r24       1
    c13       r26       1
    c13       r27       1
    c13       r37       1
    c13       r38       1
    c13       r41       1
    c13       r46       1
    c13       r53       1
    c13       r61       1
    c13       r63       1
    c13       r64       1
    c13       r75       1
    c13       r79       1
    c13       r85       1
    c13       r86       1
    c14       Obj       -1
    c14       r5        1
    c14       r24       1
    c14       r27       1
    c14       r38       1
    c14       r41       1
    c14       r42       1
    c14       r53       1
    c14       r57       1
    c14       r59       1
    c14       r62       1
    c14       r71       1
    c14       r72       1
    c14       r73       1
    c14       r74       1
    c14       r76       1
    c14       r77       1
    c14       r78       1
    c14       r81       1
    c14       r84       1
    c14       r86       1
    c15       Obj       -1
    c15       r7        1
    c15       r29       1
    c15       r34       1
    c15       r35       1
    c15       r50       1
    c15       r52       1
    c15       r53       1
    c15       r54       1
    c15       r55       1
    c15       r56       1
    c15       r60       1
    c15       r61       1
    c15       r62       1
    c15       r63       1
    c15       r64       1
    c15       r65       1
    c15       r68       1
    c15       r69       1
    c15       r74       1
    c15       r75       1
    c15       r76       1
    c15       r77       1
    c15       r86       1
    c16       Obj       -1
    c16       r8        1
    c16       r28       1
    c16       r29       1
    c16       r30       1
    c16       r39       1
    c16       r40       1
    c16       r41       1
    c16       r42       1
    c16       r47       1
    c16       r48       1
    c16       r53       1
    c16       r55       1
    c16       r66       1
    c16       r86       1
    c17       Obj       -1
    c17       r8        1
    c17       r28       1
    c17       r30       1
    c17       r40       1
    c17       r42       1
    c17       r53       1
    c17       r55       1
    c17       r56       1
    c17       r58       1
    c17       r60       1
    c17       r61       1
    c17       r63       1
    c17       r67       1
    c17       r68       1
    c17       r69       1
    c17       r70       1
    c17       r75       1
    c17       r79       1
    c17       r80       1
    c17       r82       1
    c17       r83       1
    c17       r86       1
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS_V     r0        1
    RHS_V     r1        1
    RHS_V     r2        1
    RHS_V     r3        1
    RHS_V     r4        1
    RHS_V     r5        1
    RHS_V     r6        1
    RHS_V     r7        1
    RHS_V     r8        1
    RHS_V     r9        1
    RHS_V     r10       1
    RHS_V     r11       1
    RHS_V     r12       1
    RHS_V     r13       1
    RHS_V     r14       1
    RHS_V     r15       1
    RHS_V     r16       1
    RHS_V     r17       1
    RHS_V     r18       1
    RHS_V     r19       1
    RHS_V     r20       1
    RHS_V     r21       1
    RHS_V     r22       1
    RHS_V     r23       1
    RHS_V     r24       1
    RHS_V     r25       1
    RHS_V     r26       1
    RHS_V     r27       1
    RHS_V     r28       1
    RHS_V     r29       1
    RHS_V     r30       1
    RHS_V     r31       1
    RHS_V     r32       1
    RHS_V     r33       1
    RHS_V     r34       1
    RHS_V     r35       1
    RHS_V     r36       1
    RHS_V     r37       1
    RHS_V     r38       1
    RHS_V     r39       1
    RHS_V     r40       1
    RHS_V     r41       1
    RHS_V     r42       1
    RHS_V     r43       1
    RHS_V     r44       1
    RHS_V     r45       1
    RHS_V     r46       1
    RHS_V     r47       1
    RHS_V     r48       1
    RHS_V     r49       2
    RHS_V     r50       4
    RHS_V     r51       1
    RHS_V     r52       2
    RHS_V     r53       4
    RHS_V     r54       1
    RHS_V     r55       2
    RHS_V     r56       4
    RHS_V     r57       3
    RHS_V     r58       3
    RHS_V     r59       3
    RHS_V     r60       3
    RHS_V     r61       3
    RHS_V     r62       3
    RHS_V     r63       4
    RHS_V     r64       3
    RHS_V     r65       3
    RHS_V     r66       3
    RHS_V     r67       3
    RHS_V     r68       3
    RHS_V     r69       4
    RHS_V     r70       3
    RHS_V     r71       3
    RHS_V     r72       3
    RHS_V     r73       3
    RHS_V     r74       3
    RHS_V     r75       3
    RHS_V     r76       4
    RHS_V     r77       3
    RHS_V     r78       3
    RHS_V     r79       3
    RHS_V     r80       3
    RHS_V     r81       3
    RHS_V     r82       3
    RHS_V     r83       3
    RHS_V     r84       3
    RHS_V     r85       3
    RHS_V     r86       18
RANGES
    RANGE     r86       12
BOUNDS
 BV BOUND     c0      
 BV BOUND     c1      
 BV BOUND     c2      
 BV BOUND     c3      
 BV BOUND     c4      
 BV BOUND     c5      
 BV BOUND     c6      
 BV BOUND     c7      
 BV BOUND     c8      
 BV BOUND     c9      
 BV BOUND     c10     
 BV BOUND     c11     
 BV BOUND     c12     
 BV BOUND     c13     
 BV BOUND     c14     
 BV BOUND     c15     
 BV BOUND     c16     
 BV BOUND     c17     
ENDATA
