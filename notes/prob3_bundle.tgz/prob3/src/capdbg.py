import numpy as np, sys
sys.argv=['x']
exec(open('cap.py').read().split('if __name__')[0])
rng=np.random.default_rng(1); n=3; m=6
for rep in range(10):
    P=circle_start(sorted(rng.uniform(0,1,m)),m); z=P[1:-1].ravel()+rng.normal(0,0.01,2*(m-2)); S=[]
    if not ok(unpack(z,m)): continue
    z,S=greedy(n,z,S,rng)
    Q=unpack(z,m); E=count(Q,n)
    if len(E)>=6:
        print(np.round(Q,5)); print(sorted(E)); print(ineqs(Q).round(4)); break
