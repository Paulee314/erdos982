"""Exact search for B(n): max #bad pairs, certified.
Gap formulation: g_1..g_{m-1} > 0 (m=2n), point t at p_t = g_1+..+g_t, X = 0..n-1, Y = n..m-1.
Triple (a,k,b) [a<k<b, a<n<=b] holds iff  sum_{a<t<=k} g_t - sum_{k<t<=b} g_t = 0.
DFS over pairs; each pair: 'not bad' or a midpoint index k. Realisability of the set of chosen
triples E:  {A_E g = 0, g > 0}  feasible  <=>  no y with y^T A_E >= 0, != 0  (Stiemke).
Infeasibility prunes are certified by an exact rational Stiemke vector (checked with Fractions).
Pairs whose form lies in span(A_E) are forced bad and counted (generic point of the solution set
has exactly the forced equalities). Search proves: no realisable configuration has > target bad pairs.
"""
import sys, itertools, time
from fractions import Fraction as Fr
import numpy as np, highspy

def form(a,k,b,m):
    v=[0]*(m-1)
    for t in range(a+1,k+1): v[t-1]+=1
    for t in range(k+1,b+1): v[t-1]-=1
    return v

class Span:
    """exact rational row-echelon basis"""
    def __init__(s,dim): s.rows=[]; s.piv=[]; s.dim=dim
    def reduce(s,v):
        v=[Fr(x) for x in v]
        for r,p in zip(s.rows,s.piv):
            if v[p]!=0:
                c=v[p]; v=[x-c*y for x,y in zip(v,r)]
        return v
    def add(s,v):
        v=s.reduce(v)
        p=next((i for i,x in enumerate(v) if x!=0),None)
        if p is None: return False
        c=v[p]; v=[x/c for x in v]
        # keep reduced
        nr=[]
        for r in s.rows:
            if r[p]!=0: cc=r[p]; r=[x-cc*y for x,y in zip(r,v)]
            nr.append(r)
        s.rows=nr+[v]; s.piv=s.piv+[p]; return True
    def contains(s,v): return all(x==0 for x in s.reduce(v))
    def copy(s):
        t=Span(s.dim); t.rows=list(s.rows); t.piv=list(s.piv); return t

def stiemke(rows, dim):
    """return exact rational y with y^T A >=0, !=0 if exists (=> infeasible), else None (feasible).
    LP: max sum c  s.t. c = y^T A, 0<=c<=1."""
    if not rows: return None
    R=len(rows)
    h=highspy.Highs(); h.setOptionValue('output_flag',False)
    inf=highspy.kHighsInf
    # vars: y (free, R), c (dim, [0,1])
    for i in range(R): h.addVar(-inf,inf)
    for j in range(dim): h.addVar(0,1)
    h.changeColsCost(dim, np.arange(R,R+dim,dtype=np.int32), -np.ones(dim))
    A=np.array([[float(x) for x in r] for r in rows])
    for j in range(dim):
        idx=list(range(R))+[R+j]; val=list(A[:,j])+[-1.0]
        h.addRow(0,0,len(idx),np.array(idx,dtype=np.int32),np.array(val))
    h.run()
    obj=h.getInfo().objective_function_value
    if obj>-1e-9: return None   # max sum c ~ 0 -> feasible (verified later exactly at leaves via a point)
    y=h.getSolution().col_value[:R]
    for den in (1,2,4,6,12,24,60,120,840,5040,27720,10**6):
        yr=[Fr(v).limit_denominator(den) for v in y]
        c=[sum(yr[i]*Fr(rows[i][j]) for i in range(R)) for j in range(dim)]
        if all(x>=0 for x in c) and any(x>0 for x in c): return yr
    raise RuntimeError("could not rationalise Stiemke certificate")

def exact_point(rows, dim):
    """exact rational g>0 with A g = 0 (feasibility witness), via LP g>=1 then exact projection"""
    h=highspy.Highs(); h.setOptionValue('output_flag',False)
    inf=highspy.kHighsInf
    for j in range(dim): h.addVar(1,inf)
    for r in rows:
        idx=[j for j in range(dim) if r[j]!=0]
        h.addRow(0,0,len(idx),np.array(idx,dtype=np.int32),np.array([float(r[j]) for j in idx]))
    h.changeColsCost(dim,np.arange(dim,dtype=np.int32),np.ones(dim))
    h.run(); g=h.getSolution().col_value
    # exact: solve rows*g=0 with free vars set from rounded g (parametrise via echelon)
    S=Span(dim)
    for r in rows: S.add(r)
    piv=set(S.piv); free=[j for j in range(dim) if j not in piv]
    for den in (1,2,4,8,16,64,256,1024,10**6):
        val={j:Fr(g[j]).limit_denominator(den) for j in free}
        # pivot var p: row has 1 at p, entries at other pivots 0 (reduced), so g_p = -sum r_j g_j over free
        sol=[None]*dim
        for j in free: sol[j]=val[j]
        for r,p in zip(S.rows,S.piv): sol[p]=-sum(r[j]*val[j] for j in free)
        if all(x>0 for x in sol): return sol
    return None

def search(n, target, verbose=True):
    """Find realisable configuration with >= target bad pairs, or prove none."""
    m=2*n; dim=m-1
    pairs=[(a,b) for a in range(n) for b in range(n,m)]
    # order: innermost pairs first (b-a small), ties by a desc
    pairs.sort(key=lambda p:(p[1]-p[0], -p[0]))
    P=len(pairs)
    F={(a,k,b):form(a,k,b,m) for (a,b) in pairs for k in range(a+1,b)}
    stats={'nodes':0,'lp':0,'infeas':0,'certs':[]}
    best=[None]
    assign={}  # pair -> k or None
    def options(a,b):
        lo,hi=a+1,b-1
        for (c,d),k in assign.items():
            if k is None: continue
            if c==a:
                if d<b: lo=max(lo,k+1)
                else: hi=min(hi,k-1)
            if d==b:
                if c<a: lo=max(lo,k+1)
                else: hi=min(hi,k-1)
        res=[]
        for k in range(lo,hi+1):
            okk=True
            for (c,d),kk in assign.items():
                if kk==k and not ((c<a and d>b) or (c>a and d<b)): okk=False;break
            if okk: res.append(k)
        return res
    def forced(S,a,b):
        for k in range(a+1,b):
            if S.contains(F[(a,k,b)]): return k
        return None
    def rec(i,S,rows,cnt):
        stats['nodes']+=1
        if best[0] is not None: return
        if i==P:
            if cnt>=target:
                g=exact_point(rows,dim)
                assert g is not None
                best[0]=(cnt,g,dict(assign))
            return
        # bound
        rem=0
        for (a,b) in pairs[i:]:
            if forced(S,a,b) is not None or options(a,b): rem+=1
        if cnt+rem<target: return
        a,b=pairs[i]
        fk=forced(S,a,b)
        if fk is not None:
            assign[(a,b)]=fk; rec(i+1,S,rows,cnt+1); del assign[(a,b)]; return
        opts=options(a,b)
        # try bad options first (heuristic: middle k first)
        opts.sort(key=lambda k:abs(2*k-a-b))
        for k in opts:
            v=F[(a,k,b)]
            S2=S.copy(); S2.add(v); rows2=rows+[v]
            stats['lp']+=1
            y=stiemke(rows2,dim)
            if y is not None:
                stats['infeas']+=1
                if len(stats['certs'])<2000: stats['certs'].append((list(rows2),y))
                continue
            assign[(a,b)]=k; rec(i+1,S2,rows2,cnt+1); del assign[(a,b)]
            if best[0] is not None: return
        assign[(a,b)]=None; rec(i+1,S,rows,cnt); del assign[(a,b)]
    t=time.time(); rec(0,Span(dim),[],0)
    if verbose: print("n=%d target=%d result=%s nodes=%d lp=%d infeasible=%d time=%.1fs"%(n,target,'FOUND' if best[0] else 'NONE',stats['nodes'],stats['lp'],stats['infeas'],time.time()-t),flush=True)
    return best[0],stats

if __name__=="__main__":
    n=int(sys.argv[1]); target=int(sys.argv[2])
    r,st=search(n,target)
    if r:
        cnt,g,asg=r; p=[Fr(0)]
        for x in g: p.append(p[-1]+x)
        print("points:",[str(x) for x in p])
