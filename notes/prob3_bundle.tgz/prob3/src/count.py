from fractions import Fraction as F
def bad(P):
    P=sorted(map(F,P)); n=len(P)//2; S=set(P)
    return sum(1 for x in P[:n] for y in P[n:] if (x+y)/2 in S)
if __name__=="__main__":
    for P in [[0,2,4,6,8,10,11,12,13,14,15,16,17,18,20,22,24,26,28,30],[0,2,4,6,8,10,12,14,15,16,17,18,19,20,21,22,23,24,26,28,30,32,34,36],[0,4,6,8,10,12,13,14,15,16,17,18,20,22,24,26]]:
        print(len(P)//2, bad(P))
