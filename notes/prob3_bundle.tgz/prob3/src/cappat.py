# Try to realise, as caps, incidence patterns that satisfy all cap-valid combinatorial constraints
# (row/col monotonicity = NPPZ Lemma 8, same-witness antichain) but have > B(n) edges.
import sys, numpy as np, highspy, itertools
exec(open('cap.py').read().split('if __name__')[0])
n=int(sys.argv[1]); target=int(sys.argv[2]); maxpat=int(sys.argv[3]); tries=int(sys.argv[4])
m=2*n; X=range(n); Y=range(n,m)
from fam import fam
FAMP=fam(n)[2]
trip=[(a,k,b) for a in X for b in Y for k in range(a+1,b)]
idx={t:i for i,t in enumerate(trip)}; N=len(trip)
h=highspy.Highs(); h.setOptionValue('output_flag',False)
for t in trip: h.addVar(0,1)
h.changeColsIntegrality(N,np.arange(N,dtype=np.int32),np.array([highspy.HighsVarType.kInteger]*N))
def addrow(ids,lo,ub):
    ids=sorted(set(ids)); h.addRow(lo,ub,len(ids),np.array(ids,dtype=np.int32),np.ones(len(ids)))
INF=highspy.kHighsInf
for a in X:
    for b in Y: addrow([idx[(a,k,b)] for k in range(a+1,b)],-INF,1)
for a in X:
    for b in Y:
        for b2 in Y:
            if b2<=b: continue
            for t in range(a+1,b2):
                ids=[idx[(a,k,b)] for k in range(max(t,a+1),b)]+[idx[(a,k,b2)] for k in range(a+1,min(t,b2-1)+1)]
                if len(ids)>1: addrow(ids,-INF,1)
for b in Y:
    for a in X:
        for a2 in X:
            if a2<=a: continue
            for t in range(a2+1,b):
                ids=[idx[(a,k,b)] for k in range(max(t,a+1),b)]+[idx[(a2,k,b)] for k in range(a2+1,min(t,b-1)+1)]
                if len(ids)>1: addrow(ids,-INF,1)
for k in range(1,m-1):
    prs=[(a,b) for a in X for b in Y if a<k<b]
    for (a,b) in prs:
        for (a2,b2) in prs:
            if a<a2 and b<b2: addrow([idx[(a,k,b)],idx[(a2,k,b2)]],-INF,1)
addrow(list(range(N)),target,target)
rng=np.random.default_rng(5); best=0; npat=0
# random objective to diversify
while npat<maxpat:
    h.changeColsCost(N,np.arange(N,dtype=np.int32),rng.normal(0,1,N))
    h.run()
    if h.getModelStatus()!=highspy.HighsModelStatus.kOptimal: print("no more patterns"); break
    x=h.getSolution().col_value; S=[trip[i] for i in range(N) if x[i]>0.5]
    npat+=1
    addrow([idx[t] for t in S],-INF,len(S)-1)  # no-good
    for tr in range(tries):
        if tr%2==0: P=circle_start(FAMP,m); z0=P[1:-1].ravel()+rng.normal(0,0.01*(1+tr),2*(m-2))
        else: P=circle_start(sorted(rng.uniform(0,1,m)),m); z0=P[1:-1].ravel()+rng.normal(0,0.02,2*(m-2))
        z,good=solve(z0,m,[(a,b,k) for (a,k,b) in S])
        if good:
            E=count(unpack(z,m),n)
            print(f"pattern {npat}: REALISED as cap with {len(E)} edges: {S}",flush=True)
            np.save(f"../cap_n{n}_{len(E)}.npy",unpack(z,m)); best=max(best,len(E)); break
print(f"n={n} target={target}: tried {npat} patterns, best realised {best}")
