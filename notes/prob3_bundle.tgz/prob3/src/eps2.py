import numpy as np
from scipy.optimize import brentq, minimize
def f2(a,d): return d/2-9*d*d/4-3*a*d
VAR={
 'v2-as-written  [(1-c)a^2, (n-dn)^2]':      lambda a,d,c:(1-c)*a*a-5*d/3+d*d/12,
 'v2 + size fix  [(1-c)a^2, (n-3dn)^2]':     lambda a,d,c:(1-c)*a*a-2*d+0.75*d*d,
 'conservative   [(1-c)(a-3d)^2,(n-3dn)^2]': lambda a,d,c:(1-c)*(a-3*d)**2-2*d+0.75*d*d,
}
def best(F,c):
    bv=(-1,0,0)
    for d in np.geomspace(1e-6,0.05,600):
        g=lambda a: F(a,d,c)-f2(a,d); lo,hi=3*d,1/6
        a = lo if g(lo)>0 else (hi if g(hi)<0 else brentq(g,lo,hi))
        v=min(F(a,d,c),f2(a,d))
        if v>bv[0]: bv=(v,a,d)
    r=minimize(lambda z:-min(F(z[0],z[1],c),f2(z[0],z[1])),bv[1:],method='Nelder-Mead',options={'xatol':1e-13,'fatol':1e-18,'maxiter':40000})
    if -r.fun>bv[0]: bv=(-r.fun,*r.x)
    return bv
F=VAR['v2-as-written  [(1-c)a^2, (n-dn)^2]']
print("v2 stated point a=1/8.8,d=1/1132: f1=%.4e f2=%.4e -> eps=1/%.0f"%(F(1/8.8,1/1132,7/8),f2(1/8.8,1/1132),3/min(F(1/8.8,1/1132,7/8),f2(1/8.8,1/1132))))
cs=[7/8,0.8,0.75,0.7,2/3,0.65,0.6,0.55,0.5]
for name,F in VAR.items():
    print("==",name)
    for c in cs:
        v,a,d=best(F,c)
        print("  c=%.4f  eps=1/%-6.0f (=%.3e)  a=1/%.2f d=1/%.0f   ratio to c=7/8: %.2f"%(c,3/v,v/3,1/a,1/d, v/best(F,7/8)[0]))
print("c=0 / c=0.25:")
for name,F in VAR.items():
    for c in [0.25,0.0]:
        v,a,d=best(F,c); print("  ",name,c,"eps=1/%.0f"%(3/v),"a=1/%.2f d=1/%.0f"%(1/a,1/d))
