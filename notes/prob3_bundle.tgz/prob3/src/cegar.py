"""CEGAR proof that no configuration with p x's and q y's has >= target bad pairs.
Relaxation: 0/1 variables v[a,k,b] (pair (a,b) has midpoint at point k), at most one k per pair,
plus valid combinatorial constraints (row/column monotonicity, same-k antichain).
Counterexample guided cuts: if the MIP's pattern is not realisable, a minimal infeasible subset (IIS)
of its triples is extracted, certified by an exact rational Stiemke vector, and *every* order-isomorphic
copy of it is forbidden (realisability of a set of triples depends only on the relative order of the
points it involves).  Stop when MIP optimum < target (=> proof, modulo MIP solver correctness)
or a realisable pattern with >= target is found (exact rational witness)."""
import sys, time, itertools, json
from fractions import Fraction as Fr
import numpy as np, highspy
from exact1d import stiemke, exact_point, Span

def form(a,k,b,dim):
    v=[0]*dim
    for t in range(a+1,k+1): v[t-1]+=1
    for t in range(k+1,b+1): v[t-1]-=1
    return v

def feasible(triples,dim):
    rows=[form(a,k,b,dim) for (a,k,b) in triples]
    return stiemke(rows,dim) is None

def iis(triples,dim):
    T=list(triples)
    i=0
    while i<len(T):
        t=T[:i]+T[i+1:]
        if not feasible(t,dim): T=t
        else: i+=1
    rows=[form(a,k,b,dim) for (a,k,b) in T]
    y=stiemke(rows,dim); assert y is not None
    return T,y

def normalize(T):
    I=sorted(set(i for t in T for i in t)); pos={v:j for j,v in enumerate(I)}
    return tuple(sorted(tuple(pos[i] for i in t) for t in T)), len(I)

def run(p,q,target,log=True,extra_cuts=None,timelimit=None):
    m=p+q; dim=m-1
    X=range(p); Y=range(p,m)
    trip=[(a,k,b) for a in X for b in Y for k in range(a+1,b)]
    idx={t:i for i,t in enumerate(trip)}
    N=len(trip)
    h=highspy.Highs(); h.setOptionValue('output_flag',False)
    h.setOptionValue('mip_rel_gap',0.0)
    for t in trip: h.addVar(0,1)
    h.changeColsIntegrality(N,np.arange(N,dtype=np.int32),np.array([highspy.HighsVarType.kInteger]*N))
    h.changeColsCost(N,np.arange(N,dtype=np.int32),-np.ones(N))
    def addrow(ids,ub):
        ids=sorted(set(ids))
        h.addRow(-highspy.kHighsInf,ub,len(ids),np.array(ids,dtype=np.int32),np.ones(len(ids)))
    ncons=0
    # one midpoint per pair
    for a in X:
        for b in Y:
            ids=[idx[(a,k,b)] for k in range(a+1,b)]
            if ids: addrow(ids,1); ncons+=1
    # row monotonicity: same a, b<b': k<k'.  threshold form
    for a in X:
        for b in Y:
            for b2 in Y:
                if b2<=b: continue
                for t in range(a+1,b2):
                    ids=[idx[(a,k,b)] for k in range(max(t,a+1),b)]+[idx[(a,k,b2)] for k in range(a+1,min(t,b2-1)+1)]
                    if len(ids)>1: addrow(ids,1); ncons+=1
    for b in Y:
        for a in X:
            for a2 in X:
                if a2<=a: continue
                for t in range(a2+1,b):
                    ids=[idx[(a,k,b)] for k in range(max(t,a+1),b)]+[idx[(a2,k,b)] for k in range(a2+1,min(t,b-1)+1)]
                    if len(ids)>1: addrow(ids,1); ncons+=1
    # same k antichain: (a,b),(a2,b2) with a<a2,b<b2 can't share k
    for k in range(1,m-1):
        prs=[(a,b) for a in X for b in Y if a<k<b]
        for (a,b) in prs:
            for (a2,b2) in prs:
                if a<a2 and b<b2: addrow([idx[(a,k,b)],idx[(a2,k,b2)]],1); ncons+=1
    patterns={}
    def add_pattern(pat,s):
        # all order-isomorphic embeddings into 0..m-1 that are valid triples
        c=0
        for emb in itertools.combinations(range(m),s):
            ids=[]
            okk=True
            for (a,k,b) in pat:
                tt=(emb[a],emb[k],emb[b])
                if tt not in idx: okk=False;break
                ids.append(idx[tt])
            if okk: addrow(ids,len(ids)-1); c+=1
        return c
    if extra_cuts:
        for pat,s in extra_cuts: add_pattern(pat,s); patterns[pat]=s
    it=0; t0=time.time(); ncut=0
    while True:
        it+=1
        h.run()
        st=h.getModelStatus()
        val=-h.getInfo().objective_function_value
        if st!=highspy.HighsModelStatus.kOptimal: raise RuntimeError(str(st))
        if val < target-0.5:
            if log: print(f"p={p} q={q}: PROVED max < {target} (MIP opt {val:.0f}) iters={it} patterns={len(patterns)} cuts={ncut} base={ncons} {time.time()-t0:.1f}s",flush=True)
            return ('proved',val,patterns)
        x=h.getSolution().col_value
        T=[trip[i] for i in range(N) if x[i]>0.5]
        if feasible(T,dim):
            g=exact_point([form(a,k,b,dim) for (a,k,b) in T],dim)
            pts=[Fr(0)]
            for v in g: pts.append(pts[-1]+v)
            S=set(pts); cnt=sum(1 for a in X for b in Y if (pts[a]+pts[b])/2 in S)
            if log: print(f"p={p} q={q}: FOUND pattern with {len(T)} (exact count {cnt}) iters={it}",flush=True)
            return ('found',cnt,pts)
        Tm,y=iis(T,dim)
        pat,s=normalize(Tm)
        if pat in patterns: raise RuntimeError("repeated pattern")
        patterns[pat]=s
        ncut+=add_pattern(pat,s)
        if log and it%50==0: print(f"  it={it} mip={val:.0f} pattern size={len(pat)} on {s} pts; #patterns={len(patterns)} cuts={ncut} {time.time()-t0:.0f}s",flush=True)

if __name__=="__main__":
    p,q,target=map(int,sys.argv[1:4])
    import glob
    lib={}
    for f in glob.glob('../patterns_*.json'):
        for pat,s_ in json.load(open(f)): lib[tuple(tuple(t) for t in pat)]=s_
    r=run(p,q,target,extra_cuts=[(pat,s_) for pat,s_ in lib.items() if s_<=p+q])
    if r[0]=='found': print([str(v) for v in r[2]])
    else:
        json.dump([[list(map(list,pat)),s] for pat,s in r[2].items()],open(f"../patterns_{p}_{q}.json","w"))
        print("pattern sizes:",sorted(__import__('collections').Counter((len(pt),s) for pt,s in r[2].items()).items()))
