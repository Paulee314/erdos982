# rebuild final relaxation for (n,n) with constraint sum v >= B(n)+1 and solve with CBC (independent MIP solver)
import sys, json, subprocess, os
sys.argv=[sys.argv[0]]+sys.argv[1:]
import cegar2, pulp
tab=cegar2.loadtab()
for n in map(int,sys.argv[1:]):
    B=tab[(n,n)]
    # remove (n,n) from table temporarily so window rows don't include itself (they skip it anyway)
    f=f"../final_{n}_{n}.mps"
    cegar2.solve(n,n,B,log=False,export=f)
    cbc=pulp.apis.PULP_CBC_CMD().path
    out=subprocess.run([cbc,f,"-solve"],capture_output=True,text=True).stdout
    res=[l for l in out.splitlines() if 'infeasible' in l.lower() or 'Optimal' in l or 'Result' in l]
    print(f"n={n}: CBC on relaxation with sum>= {B+1}:", res[:3])
