# NPPZ Lemma 13 argument on the 1-D extremal configurations: d(u_i)+d(v_i) <= n+i, how tight?
from fam import fam
import sys
for n in [10,20,40]:
    c,par,P=fam(n); m=2*n; S=set(P)
    deg=[0]*m
    E=[(a,b) for a in range(n) for b in range(n,m) if (P[a]+P[b])%2==0 and (P[a]+P[b])//2 in S]
    for a,b in E: deg[a]+=1; deg[b]+=1
    segs=[(P[j+1]-P[j],j) for j in range(m-1) if j!=n-1]
    segs.sort(key=lambda s:(s[0],s[1]))
    tot_bound=0; tot_actual=0; rows=[]
    for i,(L,j) in enumerate(segs,1):
        act=deg[j]+deg[j+1]; bnd=(n+i) if i<=n else 2*n
        rows.append((i,L,j,act,bnd)); tot_bound+=bnd; tot_actual+=act
    print(f"n={n} |E|={len(E)} (3n^2/5={3*n*n/5:.1f}); sum over segments of d(u)+d(v): actual={tot_actual}, NPPZ bound={tot_bound}")
    # common neighbours actually vs bound i
    import collections
    print("  first-n segments: mean slack (bound-actual) = %.2f ; last n-2: mean slack = %.2f"%(
        sum(r[4]-r[3] for r in rows[:n])/n, sum(r[4]-r[3] for r in rows[n:])/max(1,len(rows)-n)))
    if n==10:
        print("  i, len, seg-left-index, d(u)+d(v), bound"); 
        for r in rows: print("   ",r)
    print("  degrees:",deg)
