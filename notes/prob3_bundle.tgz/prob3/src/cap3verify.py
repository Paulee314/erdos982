import numpy as np, mpmath as mp
exec(open('cap.py').read().split('if __name__')[0])
mp.mp.dps=60
rng=np.random.default_rng(1); n=3; m=6
found=None
for rep in range(40):
    P=circle_start(sorted(rng.uniform(0,1,m)),m); z=P[1:-1].ravel()+rng.normal(0,0.01,2*(m-2))
    if not ok(unpack(z,m)): continue
    z,S=greedy(n,z,[],rng)
    E=count(unpack(z,m),n)
    if len(E)==6: found=(z,sorted(E)); break
z,S=found
print("incidences (c,d,witness):",S)
# Newton refine in high precision (underdetermined: min-norm steps)
Z=mp.matrix([mp.mpf(v) for v in z])
def F(Z):
    Q=[(mp.mpf(0),mp.mpf(0))]+[(Z[2*i],Z[2*i+1]) for i in range(m-2)]+[(mp.mpf(1),mp.mpf(0))]
    d2=lambda u,v:(u[0]-v[0])**2+(u[1]-v[1])**2
    return mp.matrix([d2(Q[x],Q[c])-d2(Q[x],Q[d]) for c,d,x in S]),Q
for it in range(30):
    f,Q=F(Z)
    J=mp.matrix(len(S),len(Z))
    h=mp.mpf('1e-30')
    for j in range(len(Z)):
        Z2=Z.copy(); Z2[j]+=h; f2,_=F(Z2)
        for i in range(len(S)): J[i,j]=(f2[i]-f[i])/h
    step=J.T*mp.lu_solve(J*J.T,f)
    Z=Z-step
f,Q=F(Z)
print("max residual after refinement: %s"%mp.nstr(max(abs(v) for v in f),5))
Qf=np.array([[float(a),float(b)] for a,b in Q])
print("points:\n",np.array2string(Qf,precision=6))
g=ineqs(Qf); print("min convexity/cap/gap margin:",g.min())
print("edges witnessed (tol 1e-9):",len(count(Qf,n)))
