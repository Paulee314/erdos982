import numpy as np
from scipy.optimize import minimize_scalar, brentq
def f2(a,d): return d/2-9*d*d/4-3*a*d
def f1(a,d,c,ver):
    if ver=='corrected': return (1-c)*(a-3*d)**2-2*d+0.75*d*d     # |P_i|>= n-3dn
    else: return (1-c)*(a-3*d)**2-5*d/3+d*d/12                   # preprint's (n-dn)^2
def best(c,ver):
    # maximize min(f1,f2) over a,d by grid + refine
    bestv=(-1,0,0)
    for d in np.geomspace(1e-6,0.05,400):
        # for fixed d, f2 decreasing in a, f1 increasing in a (a>3d): optimum at crossing
        lo,hi=3*d,1/6
        g=lambda a: f1(a,d,c,ver)-f2(a,d)
        if g(lo)>0: a=lo
        elif g(hi)<0: a=hi
        else: a=brentq(g,lo,hi)
        v=min(f1(a,d,c,ver),f2(a,d))
        if v>bestv[0]: bestv=(v,a,d)
    v,a,d=bestv
    # refine
    from scipy.optimize import minimize
    r=minimize(lambda z:-min(f1(z[0],z[1],c,ver),f2(z[0],z[1])),[a,d],method='Nelder-Mead',options={'xatol':1e-12,'fatol':1e-16,'maxiter':20000})
    a,d=r.x; v=-r.fun
    return v,a,d
print("check paper point (preprint ver, c=7/8): f1=%.4e f2=%.4e"%(f1(1/8.87,1/1204.5,7/8,'pre'),f2(1/8.87,1/1204.5)))
print("same point corrected f1=%.4e"%f1(1/8.87,1/1204.5,7/8,'corrected'))
for ver in ['pre','corrected']:
  print("==",ver)
  for c in [7/8,0.85,0.8,0.75,0.7,0.65,0.6,0.55,0.5]:
    v,a,d=best(c,ver)
    print("c=%.4f  margin f=%.4e  eps=f/3=%.4e = 1/%.0f   a=1/%.3f d=1/%.1f  good-edge coeff 1/%.4f  bound on Z: %.6f n^2"%(c,v,v/3,3/v,1/a,1/d,1/(1/12+v),1-(1/12+v)))
