// simulated annealing over integer sets in [0,N] for bad-pair count
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
static unsigned long long rs=88172645463325252ULL;
static inline unsigned long long rnd(){rs^=rs<<13;rs^=rs>>7;rs^=rs<<17;return rs;}
int n,N; int *P; char *in;
int cmpi(const void*a,const void*b){return *(int*)a-*(int*)b;}
int score(){
  int s[64]; int m=2*n; int c=0;
  memcpy(s,P,sizeof(int)*m); qsort(s,m,sizeof(int),cmpi);
  for(int i=0;i<n;i++)for(int j=n;j<m;j++){int t=s[i]+s[j]; if(!(t&1) && in[t/2]) c++;}
  return c;
}
int main(int argc,char**argv){
  n=atoi(argv[1]); N=atoi(argv[2]); long iters=atol(argv[3]); int restarts=atoi(argv[4]); rs^=atol(argv[5])*2654435761ULL;
  int m=2*n; P=malloc(sizeof(int)*m); in=calloc(N+1,1);
  int best=-1; int bestP[64];
  for(int r=0;r<restarts;r++){
    memset(in,0,N+1);
    for(int i=0;i<m;i++){int v;do v=rnd()%(N+1);while(in[v]);in[v]=1;P[i]=v;}
    int cur=score(); double T=2.0;
    for(long it=0;it<iters;it++){
      T=2.0*(1.0-(double)it/iters)+0.05;
      int idx=rnd()%m; int old=P[idx]; int v;
      if(rnd()%2){ v=old+(int)(rnd()%7)-3; if(v<0||v>N) continue;} else v=rnd()%(N+1);
      if(in[v]) continue;
      in[old]=0; in[v]=1; P[idx]=v;
      int ns=score();
      if(ns>=cur || exp((ns-cur)/T) > (rnd()%1000000)/1e6){cur=ns; if(cur>best){best=cur; memcpy(bestP,P,sizeof(int)*m);} }
      else {in[v]=0; in[old]=1; P[idx]=old;}
    }
  }
  qsort(bestP,m,sizeof(int),cmpi);
  printf("n=%d best=%d floor(n^2/2)=%d :",n,best,n*n/2);
  for(int i=0;i<m;i++)printf(" %d",bestP[i]-bestP[0]); printf("\n");
}
