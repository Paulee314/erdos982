"""Optimisation-mode CEGAR for B(p,q) (p x's then q y's), with window constraints from smaller cases.
Window constraint: pairs (a,b) with a>=a0 and b<=b0 have their midpoints inside [a0,b0], so they form an
instance with (p-a0) x's and (b0-p+1) y's: their number is <= B(p-a0, b0-p+1)."""
import sys, time, itertools, json, glob
from fractions import Fraction as Fr
import numpy as np, highspy
from exact1d import stiemke, exact_point
from cegar import form, feasible, iis, normalize
TAB='../Bpq.json'
def loadtab():
    try: return {tuple(map(int,k.split(','))):v for k,v in json.load(open(TAB)).items()}
    except Exception: return {}
def savetab(t): json.dump({f"{a},{b}":v for (a,b),v in t.items()},open(TAB,'w'),indent=0)
def loadlib():
    lib={}
    for f in glob.glob('../patterns_*.json'):
        for pat,s_ in json.load(open(f)): lib[tuple(tuple(t) for t in pat)]=s_
    return lib
def solve(p,q,lb,log=True,export=None):
    m=p+q; dim=m-1; X=range(p); Y=range(p,m)
    tab=loadtab(); lib=loadlib()
    trip=[(a,k,b) for a in X for b in Y for k in range(a+1,b)]
    idx={t:i for i,t in enumerate(trip)}; N=len(trip)
    if N==0:
        tab=loadtab(); tab[(p,q)]=0; savetab(tab); print(f'B({p},{q}) = 0 (no triples)'); return 0,None
    h=highspy.Highs(); h.setOptionValue('output_flag',False); h.setOptionValue('mip_rel_gap',0.0)
    for t in trip: h.addVar(0,1)
    h.changeColsIntegrality(N,np.arange(N,dtype=np.int32),np.array([highspy.HighsVarType.kInteger]*N))
    h.changeColsCost(N,np.arange(N,dtype=np.int32),-np.ones(N))
    def addrow(ids,ub,lbv=None):
        ids=sorted(set(ids))
        h.addRow(-highspy.kHighsInf if lbv is None else lbv,ub,len(ids),np.array(ids,dtype=np.int32),np.ones(len(ids)))
    for a in X:
        for b in Y: addrow([idx[(a,k,b)] for k in range(a+1,b)],1)
    for a in X:
        for b in Y:
            for b2 in Y:
                if b2<=b: continue
                for t in range(a+1,b2):
                    ids=[idx[(a,k,b)] for k in range(max(t,a+1),b)]+[idx[(a,k,b2)] for k in range(a+1,min(t,b2-1)+1)]
                    if len(ids)>1: addrow(ids,1)
    for b in Y:
        for a in X:
            for a2 in X:
                if a2<=a: continue
                for t in range(a2+1,b):
                    ids=[idx[(a,k,b)] for k in range(max(t,a+1),b)]+[idx[(a2,k,b)] for k in range(a2+1,min(t,b-1)+1)]
                    if len(ids)>1: addrow(ids,1)
    for k in range(1,m-1):
        prs=[(a,b) for a in X for b in Y if a<k<b]
        for (a,b) in prs:
            for (a2,b2) in prs:
                if a<a2 and b<b2: addrow([idx[(a,k,b)],idx[(a2,k,b2)]],1)
    nwin=0
    for a0 in X:
        for b0 in Y:
            pp,qq=p-a0,b0-p+1
            if (pp,qq)==(p,q): continue
            key=(pp,qq) if (pp,qq) in tab else ((qq,pp) if (qq,pp) in tab else None)
            if key is None: continue
            ids=[idx[(a,k,b)] for a in range(a0,p) for b in range(p,b0+1) for k in range(a+1,b)]
            if ids: addrow(ids,tab[key]); nwin+=1
    patterns={}
    def add_pattern(pat,s):
        c=0
        for emb in itertools.combinations(range(m),s):
            ids=[]
            for (a,k,b) in pat:
                tt=(emb[a],emb[k],emb[b])
                if tt not in idx: ids=None;break
                ids.append(idx[tt])
            if ids: addrow(ids,len(ids)-1); c+=1
        return c
    for pat,s in lib.items():
        if s<=m: add_pattern(pat,s); patterns[pat]=s
    newpat={}
    best=lb; bestpts=None; t0=time.time(); it=0
    addrow(list(range(N)),N,best+1)   # objective cut: >= best+1  (row index = current last)
    cutrow=h.getNumRow()-1
    if export:
        h.writeModel(export); return None,None
    while True:
        it+=1
        h.run(); st=h.getModelStatus()
        if st==highspy.HighsModelStatus.kInfeasible:
            if log: print(f"B({p},{q}) = {best} PROVED (no realisable pattern with >= {best+1}); iters={it} new patterns={len(newpat)} windows={nwin} {time.time()-t0:.1f}s",flush=True)
            break
        if st!=highspy.HighsModelStatus.kOptimal: raise RuntimeError(str(st))
        x=h.getSolution().col_value
        T=[trip[i] for i in range(N) if x[i]>0.5]
        if feasible(T,dim):
            g=exact_point([form(a,k,b,dim) for (a,k,b) in T],dim)
            pts=[Fr(0)]
            for v in g: pts.append(pts[-1]+v)
            S=set(pts); cnt=sum(1 for a in X for b in Y if (pts[a]+pts[b])/2 in S)
            assert cnt>=len(T)
            best=cnt; bestpts=pts
            if log: print(f"  B({p},{q}) >= {cnt} (exact witness) it={it} {time.time()-t0:.1f}s",flush=True)
            h.changeRowBounds(cutrow,best+1,N)
            continue
        Tm,y=iis(T,dim)
        pat,s=normalize(Tm)
        assert pat not in patterns
        patterns[pat]=s; newpat[pat]=s
        add_pattern(pat,s)
        if log and it%25==0: print(f"  it={it} pattern {len(pat)} triples/{s} pts, new={len(newpat)} {time.time()-t0:.0f}s",flush=True)
    tab=loadtab(); tab[(p,q)]=best; savetab(tab)
    if newpat: json.dump([[list(map(list,pt)),s] for pt,s in newpat.items()],open(f"../patterns_opt_{p}_{q}.json","w"))
    return best,bestpts
if __name__=="__main__":
    maxs=int(sys.argv[1])
    for s in range(2,maxs+1):
        for p in range(1,s):
            q=s-p
            if p>q: continue   # B(p,q)=B(q,p) by reflection
            tab=loadtab()
            if (p,q) in tab: continue
            b,pts=solve(p,q,0)
            print(f"RESULT B({p},{q})={b} witness={[str(v) for v in pts] if pts else None}",flush=True)
