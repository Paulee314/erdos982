# Numeric search: 2n points in a cap, count L-R edges with a witness (equidistant point of Q).
import numpy as np, sys, random
from scipy.optimize import least_squares
TOL=1e-9; MARG=1e-3
def unpack(z,m):
    Q=np.zeros((m,2)); Q[m-1]=[1,0]; Q[1:m-1]=z.reshape(m-2,2); return Q
def ineqs(Q):
    m=len(Q); g=[]
    for i in range(m):   # convex position in this order: every triple i<j<k clockwise
      for j in range(i+1,m):
        for k in range(j+1,m):
          a,b,c=Q[i],Q[j],Q[k]
          g.append(-((b-a)[0]*(c-a)[1]-(b-a)[1]*(c-a)[0]))
    for i in range(1,m-1):  # cap: angle q1 qi qm >= 90deg
        g.append(-np.dot(Q[0]-Q[i],Q[m-1]-Q[i]))
    for i in range(m-1): g.append(np.sum((Q[i+1]-Q[i])**2)-0.003)  # min gap
    return np.array(g)  # want all >= MARG*something
def resid(z,m,S):
    Q=unpack(z,m)
    r=[np.sum((Q[x]-Q[c])**2)-np.sum((Q[x]-Q[d])**2) for (c,d,x) in S]
    g=ineqs(Q); pen=np.minimum(g-MARG,0)*10
    return np.concatenate([np.array(r,dtype=float),pen])
def count(Q,n):
    m=2*n; E=set()
    for c in range(n):
        for d in range(n,m):
            for x in range(c+1,d):
                if abs(np.sum((Q[x]-Q[c])**2)-np.sum((Q[x]-Q[d])**2))<TOL: E.add((c,d,x)); break
    return E
def ok(Q): return np.all(ineqs(Q)>MARG/2)
def solve(z0,m,S):
    r=least_squares(resid,z0,args=(m,S),xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=4000)
    Q=unpack(r.x,m)
    rr=resid(r.x,m,S)
    return r.x, (np.max(np.abs(rr)) if len(rr) else 0)<1e-11 and ok(Q)
def circle_start(angles,m):
    # place on arc of circle so that q1=(0,0), qm=(1,0); arc span < 180deg
    th=np.array(angles,float); th=(th-th[0])/(th[-1]-th[0])  # 0..1
    span=np.pi*0.9; phi=np.pi/2+span/2-th*span   # angles on unit circle, descending
    P=np.stack([np.cos(phi),np.sin(phi)],1)
    P=P-P[0]; ang=np.arctan2(P[-1,1],P[-1,0]); R=np.array([[np.cos(-ang),-np.sin(-ang)],[np.sin(-ang),np.cos(-ang)]])
    P=P@R.T; P=P/P[-1,0]
    if P[1:-1,1].mean()<0: P[:,1]*=-1
    return P
def greedy(n,z,S,rng,passes=2):
    m=2*n
    cands=[(c,d,x) for c in range(n) for d in range(n,m) for x in range(c+1,d)]
    for _ in range(passes):
        rng.shuffle(cands)
        for t in cands:
            E=count(unpack(z,m),n)
            if any((e[0],e[1])==(t[0],t[1]) for e in E): continue
            z2,good=solve(z+rng.normal(0,1e-4,len(z)),m,S+[t])
            if good:
                E2=count(unpack(z2,m),n)
                if len(E2)>len(E): z=z2; S=S+[t]
    return z,S
if __name__=="__main__":
    n=int(sys.argv[1]); mode=sys.argv[2]; reps=int(sys.argv[3]); seed=int(sys.argv[4])
    rng=np.random.default_rng(seed); m=2*n; best=0
    for rep in range(reps):
        if mode=='circle':
            ang=[int(v) for v in sys.argv[5].split(',')]
            P=circle_start(ang,m); z=P[1:-1].ravel().copy(); S=[]
            E=count(P,n); S=list(E)
        else:
            P=circle_start(sorted(rng.uniform(0,1,m)),m); z=P[1:-1].ravel()+rng.normal(0,0.01,2*(m-2)); S=[]
            if not ok(unpack(z,m)): continue
        z,S=greedy(n,z,S,rng)
        E=count(unpack(z,m),n)
        if len(E)>best: best=len(E); print("rep",rep,"edges",len(E),flush=True)
    print("n=%d mode=%s best=%d"%(n,mode,best))
