# augment 1-D optimum placed on a circular arc: try to add witnessed edges by leaving the circle
import numpy as np, sys, json
exec(open('cap.py').read().split('if __name__')[0])
from fam import fam
def jac_rank(z,m,S):
    eps=1e-7; f0=np.array([np.sum((unpack(z,m)[x]-unpack(z,m)[c])**2)-np.sum((unpack(z,m)[x]-unpack(z,m)[d])**2) for c,d,x in S])
    J=[]
    for i in range(len(z)):
        z2=z.copy(); z2[i]+=eps; Q=unpack(z2,m)
        J.append((np.array([np.sum((Q[x]-Q[c])**2)-np.sum((Q[x]-Q[d])**2) for c,d,x in S])-f0)/eps)
    J=np.array(J).T
    return np.linalg.matrix_rank(J,tol=1e-5)
n=int(sys.argv[1]); passes=int(sys.argv[2]); seed=int(sys.argv[3])
rng=np.random.default_rng(seed); m=2*n
c,par,P=fam(n)
Q=circle_start(P,m); z=Q[1:-1].ravel().copy()
E=count(Q,n); S=sorted(E)
print(f"n={n}: 1-D optimum B={c}, on circle edges={len(E)}, dof={2*m-4}, rank(J)={jac_rank(z,m,S)} -> local solution dim {2*m-4-jac_rank(z,m,S)}",flush=True)
z,S=greedy(n,z,S,rng,passes=passes)
E=count(unpack(z,m),n)
print(f"n={n}: after augmentation edges={len(E)} (B(n)={c}, excess {len(E)-c}); n(n-1)={n*(n-1)}",flush=True)
np.save(f"../cap_aug_{n}_{seed}.npy",unpack(z,m))
