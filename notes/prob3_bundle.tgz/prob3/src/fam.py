# family: evens block | consecutive run | evens block ; search parameters for each n
from count import bad
def fam(n):
    best=(-1,None)
    m=2*n
    for r in range(0,m+1):            # consecutive run length
        for L in range(0,m-r+1):      # number of even points left of run
            R=m-r-L
            # left evens end at s-2 or s-1 (gap 2 to run start or 1), right evens start at e+2 or e+1
            for gl in (1,2):
              for gr in (1,2):
                s=2*L+ (gl-2)            # run start
                P=[2*i for i in range(L)]
                if r: P+=list(range(s, s+r))
                start=(s+r-1 if r else s-1)+gr
                P+=[start+2*i for i in range(R)]
                if len(set(P))!=m or sorted(P)!=P: continue
                c=bad(P)
                if c>best[0]: best=(c,(r,L,R,gl,gr),P)
    return best
if __name__=='__main__':
 for n in range(2,31):
    c,par,P=fam(n)
    print(n,c,3*n*n//5,"OK" if c==3*n*n//5 else "DIFF", par)
